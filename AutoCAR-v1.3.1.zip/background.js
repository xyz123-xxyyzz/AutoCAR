// AutoCAR Master AI - Background Script

const CONFIG = {
  PORTAL_URL: "https://auto-car-gold.vercel.app/analiz",
  SUPABASE_URL: "https://jwffcfjuydjjzqtwjitn.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_ESKWW6qt0VZL9_GwNEM3Uw_Z8wUMnOM"
};

let trackedTabs = [];
let isAnalyzing = false;
let analysisProgress = 0;
let aiStatusText = "";
let finalReport = null;
let aiError = false;
let collectedVehicles = [];
let isCollecting = false;
let isAnalysisCancelled = false;

// Initialize state
chrome.storage.local.get([
  'trackedTabs', 'isAnalyzing', 'analysisProgress', 'aiStatusText', 
  'finalReport', 'aiError', 'collectedVehicles', 'isCollecting',
  'activeBatchId', 'batchFlatCars', 'batchConfig', 'deviceId'
], async (res) => {
  if (res.trackedTabs) trackedTabs = res.trackedTabs;
  if (res.isAnalyzing !== undefined) isAnalyzing = res.isAnalyzing;
  if (res.analysisProgress !== undefined) analysisProgress = res.analysisProgress;
  if (res.aiStatusText) aiStatusText = res.aiStatusText;
  if (res.finalReport) finalReport = res.finalReport;
  if (res.aiError !== undefined) aiError = res.aiError;
  if (res.collectedVehicles) collectedVehicles = res.collectedVehicles;
  if (res.isCollecting !== undefined) isCollecting = res.isCollecting;

  if (res.activeBatchId && res.isAnalyzing && res.deviceId) {
    let sessionApiKey = '';
    try {
      const keyRes = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/rpc/get_session_api_key`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': CONFIG.SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY}`
        },
        body: JSON.stringify({ p_device_id: res.deviceId })
      });
      if (keyRes.ok) {
        const keyData = await keyRes.json();
        if (keyData && keyData.api_key) sessionApiKey = keyData.api_key;
      }
    } catch(e) {
      console.error("Auto-resume API Key retrieval failed:", e);
    }
    if (sessionApiKey) {
      console.log("Resuming OpenAI Batch Polling for:", res.activeBatchId);
      resumeBatchPolling(res.activeBatchId, res.batchFlatCars, res.batchConfig, sessionApiKey);
    }
  }
});

const DEFAULT_ANALYZE_PROMPT = `You are a highly realistic, strictly objective, and deeply analytical Automotive Expert AI.
Your goal is to find the ABSOLUTE TRUTH about the car data provided (specs, price, damage history, mileage).
Do not trust seller exaggerations or marketing fluff. Be 100% realistic and fair based purely on data.

CRITICAL JSON OUTPUT FORMAT:
You must return ONLY a single, valid JSON object exactly matching the structure below. Do not output markdown, do not output explanations outside the JSON.

{
  "clean_title": "Cleaned up Make, Model and Year of the car (e.g., 'Volkswagen Passat 2015'). Remove advertising words.",
  
  "competitor_analysis": {
    "competitors": ["Competitor 1", "Competitor 2"],
    "text": "Detailed comparison against competitors. Be highly objective, realistic, and highlight any real red flags.",
    "pros": ["Strong point 1", "Strong point 2"],
    "cons": ["Weak point 1", "Weak point 2"]
  },
  
  "market_speed_score": 85,
  "price_perf_score": 60,
  "fair_price_score": 50,
  "condition_score": 40,
  "overall_score": 61,
  
  "ai_report": "A very detailed summary report about the car's technical data in Turkish. YOU MUST EXPLICITLY AND TRANSPARENTLY EXPLAIN WHY YOU GAVE THE SPECIFIC SCORES for Satış Hızı, Fiyat/Performans, Uygunluk, and Araç Durumu. Break down the reasoning for the 4 scores. Use exactly ONE EMPTY LINE (\\n\\n) between each score's explanation.",
  
  "detailed_specs": [
    { "name": "Spec Name", "value": "Value", "status": "good", "comment": "Detailed expert professional comment explaining why this spec is an advantage or a disadvantage in the real world." }
  ],
  
  "damage_map": {
    "kaput": "orijinal"
  }
}

INSTRUCTIONS FOR SPECIFIC FIELDS:

1. SCORING (INTEGERS ONLY):
- market_speed_score: 0-100 (Volume of listings / popularity).
- price_perf_score: 0-100 (Features vs Price).
- fair_price_score: 0-100 (Is it priced at fair market value? Evaluate realistically).
- condition_score: 0-100 (Year, Mileage, Damage).
- overall_score: EXACT ARITHMETIC MEAN of the above 4 scores.

2. DETAILED SPECS (CRITICAL):
- You MUST EXTRACT AND ANALYZE ALL AVAILABLE SPECS from the data (at least 15-20 specs if available, e.g., Motor Gücü, Model Yılı, Vites Tipi, Yakıt, Renk, Boya/Değişen, Hasar Kaydı vb.).
- Do NOT just pick 3 features. Put ALL OF THEM in the 'detailed_specs' array.
- Write detailed, professional comments for every single one. The status must be one of: 'good', 'bad', or 'neutral'.

3. DAMAGE MAP:
- Map damage values based on user data. Keep keys simple and in Turkish (e.g. 'kaput', 'tavan', 'sag_on_kapi').

GENERAL CRITICAL RULES:
- All text MUST be in TURKISH. 
- Be 100% realistic and purely data-driven.
- Do not trust seller claims or 'clean' labels if the data (like mileage or damage) says otherwise.
- Do NOT hallucinate data. Be totally objective and strict.`;

// Otomatik Cihaz Oturumu Eşitleme (Vercel deploy gerektirmez)
chrome.storage.onChanged.addListener(async (changes, namespace) => {
  if (namespace === 'local' && (changes.userEmail || changes.deviceId)) {
    const res = await new Promise(r => chrome.storage.local.get(['userEmail', 'deviceId'], r));
    if (res.userEmail && res.deviceId) {
      fetch(`${CONFIG.SUPABASE_URL}/rest/v1/rpc/register_device_session`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': CONFIG.SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY}`
        },
        body: JSON.stringify({ p_device_id: res.deviceId, p_email: res.userEmail })
      }).catch(console.error);
    }
  }
});

function updateState(updates) {
  if (updates.trackedTabs !== undefined) trackedTabs = updates.trackedTabs;
  if (updates.isAnalyzing !== undefined) isAnalyzing = updates.isAnalyzing;
  if (updates.analysisProgress !== undefined) analysisProgress = updates.analysisProgress;
  if (updates.aiStatusText !== undefined) aiStatusText = updates.aiStatusText;
  if (updates.finalReport !== undefined) finalReport = updates.finalReport;
  if (updates.aiError !== undefined) aiError = updates.aiError;
  if (updates.collectedVehicles !== undefined) collectedVehicles = updates.collectedVehicles;
  if (updates.isCollecting !== undefined) isCollecting = updates.isCollecting;
  chrome.storage.local.set(updates);
}

function addTabToTrackingAndExtract(tabId, url, title, currentTrackedTabs = null) {
  if (currentTrackedTabs) {
    trackedTabs = currentTrackedTabs;
  }
  let existingUrl = trackedTabs.find(t => t.url === url);
  if (existingUrl) return;

  const newTab = {
    tabId: tabId,
    url: url,
    title: title || url,
    status: 'Yükleniyor...',
    data: null
  };
  trackedTabs.push(newTab);
  updateState({ trackedTabs });

  // Try direct messaging first for instant extraction
  chrome.tabs.sendMessage(tabId, { action: "extract_data" }, (response) => {
    let err = chrome.runtime.lastError;
    if (err || !response) {
      // Content script not loaded or tab sleeping. Try injecting it.
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['content.js']
      }, () => {
        let err2 = chrome.runtime.lastError;
        if (err2) {
          // Injection failed, likely discarded. Wake it up by reloading.
          chrome.tabs.reload(tabId);
        } else {
          // Injection succeeded, try messaging again
          chrome.tabs.sendMessage(tabId, { action: "extract_data" }, (response2) => {
            let err3 = chrome.runtime.lastError;
            if (!err3 && response2 && response2.title) {
              updateTabStatus(url, 'Yüklendi', response2);
            } else {
              // Failed again, reload to trigger automatic passive_extract
              chrome.tabs.reload(tabId);
            }
          });
        }
      });
    } else if (response && response.title) {
      updateTabStatus(url, 'Yüklendi', response);
    } else {
      // Empty response, reload as fallback to wake tab up
      chrome.tabs.reload(tabId);
    }
  });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  chrome.storage.local.get(['isCollecting', 'isAnalyzing', 'trackedTabs'], (res) => {
    const isCollecting = res.isCollecting || false;
    const isAnalyzing = res.isAnalyzing || false;
    const currentTrackedTabs = res.trackedTabs || [];

    if (!isCollecting || isAnalyzing) return;
    const url = changeInfo.url || tab.url;
    if (changeInfo.status === 'complete' && url) {
      if (url.includes('sahibinden.com/ilan/') || url.includes('arabam.com/ilan/')) {
        addTabToTrackingAndExtract(tabId, url, tab.title, currentTrackedTabs);
      }
    }
  });
});

function updateTabStatus(url, status, data = null) {
  chrome.storage.local.get(['trackedTabs'], (res) => {
    trackedTabs = res.trackedTabs || [];
    const t = trackedTabs.find(x => x.url === url);
    if (t) {
      t.status = status;
      if (data) {
        t.data = data;
        t.title = data.title || t.url;
      }
      updateState({ trackedTabs });
    }
  });
}

// ------------------------------------------------------------------
// OPENAI API CALL LOGIC
// ------------------------------------------------------------------
async function callOpenAI(systemPrompt, userContent, apiKey, model = 'gpt-4o-mini', retries = 1) {
  if (!apiKey || apiKey.trim().length === 0) {
    throw new Error('API Hatası: Bu cihaza tanımlı bir oturum bulunamadı. Lütfen web portalından bir kez giriş yapın.');
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 saniye zaman aşımı

  try {
    let messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: JSON.stringify(userContent) }
    ];

    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
      body: JSON.stringify({
        model: model,
        messages: messages,
        max_tokens: 4096,
        response_format: { type: 'json_object' }
      }),
      signal: controller.signal
    });
    const json = await res.json();
    
    if (!res.ok) {
      if (res.status === 401) throw new Error('API Anahtarı eksik veya geçersiz.');
      if (res.status === 429) {
        if (json.error && json.error.code === 'insufficient_quota') {
          throw new Error('Yapay Zeka (OpenAI) Bakiyeniz Tükenmiştir.');
        }
        if (retries > 0) {
          console.warn(`429 Too Many Requests. Retrying in 4 seconds... (${retries} left)`);
          await new Promise(r => setTimeout(r, 4000));
          return await callOpenAI(systemPrompt, userContent, apiKey, model, retries - 1);
        }
      }
      if (res.status >= 500 && retries > 0) {
          console.warn(`OpenAI Sunucu Hatası. Retrying in 4 seconds... (${retries} left)`);
          await new Promise(r => setTimeout(r, 4000));
          return await callOpenAI(systemPrompt, userContent, apiKey, model, retries - 1);
      }
      throw new Error('Yapay Zeka geçici bir hata verdi. Kod: ' + res.status);
    }
    const parsedJSON = JSON.parse(json.choices[0].message.content);
    clearTimeout(timeoutId);
    return parsedJSON;
  } catch (err) {
    clearTimeout(timeoutId);
    console.error(err);
    if (err.name === 'AbortError') {
      if (retries > 0) {
        console.warn(`Zaman aşımı (Timeout). Tekrar deneniyor...`);
        return await callOpenAI(systemPrompt, userContent, apiKey, model, retries - 1);
      } else {
        throw new Error('Yapay Zeka (OpenAI) 15 saniye içinde yanıt vermedi (Zaman Aşımı).');
      }
    } else if (err.message && (err.message.includes('NetworkError') || err.message.includes('Failed to fetch'))) {
      throw new Error(`İnternet bağlantısı koptu veya tarayıcı izin vermedi. Detay: ${err.message}`);
    } else {
      throw err;
    }
  }
}

function groupTabsByModel(readyData) {
  const groups = {};
  readyData.forEach(car => {
    let titleParts = car.title.split(' ');
    let groupName = 'Diğer Araçlar';
    if (titleParts.length >= 2) {
      groupName = `${titleParts[0]} ${titleParts[1]}`;
    } else if (titleParts.length === 1) {
      groupName = titleParts[0];
    }
    
    if (!groups[groupName]) {
      groups[groupName] = [];
    }
    groups[groupName].push(car);
  });
  return groups;
}

async function analyzeCarData(carData, dynamicPrompt, apiKey) {
  const systemPrompt = dynamicPrompt || DEFAULT_ANALYZE_PROMPT;

  const dataForAi = { ...carData };
  delete dataForAi.images;
  
  try {
    return await callOpenAI(systemPrompt, dataForAi, apiKey);
  } catch (error) {
    console.error(`Araç analiz edilemedi (${carData.title}):`, error);
    return {
      clean_title: carData.title || "Bilinmeyen Araç",
      market_speed_score: 0,
      price_perf_score: 0,
      fair_price_score: 0,
      condition_score: 0,
      overall_score: 0,
      ai_report: `Bu araç analiz edilemedi. Hata: ${error.message}`,
      detailed_specs: [],
      competitor_analysis: null,
      damage_map: null
    };
  }
}

async function generateGlobalMasterReport(groupReports, dynamicPrompt, apiKey) {
  const systemPrompt = dynamicPrompt || `Sen sistemin 'Master AI' yöneticisisin. Tüm araç gruplarının analiz raporları sana geliyor. Bu grupları birbiriyle kıyasla, FİYAT-PERFORMANS ve SEGMENT mantığını dikkate alarak gelen araçları sırala ve sana verilen tüm arabaların hepsini değerlendirerek listele. En iyi araçları belirle.
SADECE GEÇERLİ BİR JSON DÖNDÜR.
Format:
{
  "title": "Master AI Derinlemesine Kıyaslama Raporu (Top Seçimler)",
  "logic": "Bu liste neye göre hazırlandı? Kısaca açıkla.",
  "top_10": [
    { 
      "rank": 1,
      "title": "Volkswagen Passat 2015", 
      "score": 95, 
      "comment": "Piyasanın en dolu paketi, fiyatı ise emsallerine göre %10 daha ucuz. Neden birinci seçildiği detayı." 
    },
    { 
      "rank": 2,
      "title": "Skoda Superb 2018", 
      "score": 92, 
      "comment": "Düşük kilometresi ve temiz ekspertizi ile uzun yıllar masrafsız binilecek bir araç. Neden ikinci seçildiği." 
    }
  ],
  "details": [
    { "icon": "info", "title": "Rakipleri Neler?", "desc": "Gelen araçların genel bir piyasa analizi." },
    { "icon": "star", "title": "Bütçe ve Kitle", "desc": "Hangi kitleye hitap ediyorlar?" }
  ]
}
Kurallar:
- "score" alanlarına kafandan puan uydurma! Sana verilen verideki "overall_score" değeri neyse BİREBİR aynısını yaz.
- "title" kısmına ASLA HAM İLAN BAŞLIĞINI KOPYALAMA! Sadece aracın MARKASI, MODELİ ve YILINI tertemiz bir şekilde yaz (Örn: "Volkswagen Passat 2015").
- "comment" kısmı kesinlikle SADECE 1 CÜMLE olmalı. O aracın neden o sıraya yerleştiğini ve öne çıktığını çok vurucu şekilde yaz.
- Sana verilen araçların hepsini "top_10" dizisine sırasıyla ekle.
`;

  const cleanGroupReports = groupReports.map(g => ({
    groupName: g.groupName,
    cars: g.cars.map(c => ({
      title: c.title,
      price: c.price,
      overall_score: c.overall_score,
      ai_report: c.ai_report || ""
    }))
  }));

  return await callOpenAI(systemPrompt, cleanGroupReports, apiKey);
}

// ------------------------------------------------------------------
// RUN FULL ANALYSIS (100 CHUNKS, 60s LIMIT, TIE BREAKER)
// ------------------------------------------------------------------
async function runFullAnalysis() {
  const readyData = trackedTabs.map(t => t.data).filter(d => d !== null);
  
  if (readyData.length === 0) {
    updateState({
      aiStatusText: `Hata: Analiz edilecek araç bulunamadı.`,
      analysisProgress: 100,
      isAnalyzing: false,
      aiError: true
    });
    return;
  }

  try {
    updateState({ aiStatusText: "Sistem konfigürasyonu alınıyor...", analysisProgress: 2 });
    
    let activeConfig = { analyze_prompt: null, master_prompt: null };
    try {
      const configRes = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/rpc/get_system_config`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': CONFIG.SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY}`
        }
      });
      if (configRes.ok) {
        const configData = await configRes.json();
        if (configData) {
          activeConfig.analyze_prompt = configData.analyze_prompt;
          activeConfig.master_prompt = configData.master_prompt;
        }
      }
    } catch(e) {
      console.warn("System config couldn't be fetched, using defaults.", e);
    }

    let sessionApiKey = '';
    const storageRes = await new Promise(r => chrome.storage.local.get(['deviceId', 'userEmail'], r));
    
    if (storageRes.deviceId && storageRes.userEmail) {
      try {
        await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/rpc/register_device_session`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': CONFIG.SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY}`
          },
          body: JSON.stringify({ p_device_id: storageRes.deviceId, p_email: storageRes.userEmail })
        });
      } catch(e) {
        console.error("Device session auto-register failed.", e);
      }
    }

    if (storageRes.deviceId) {
      try {
        const keyRes = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/rpc/get_session_api_key`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': CONFIG.SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY}`
          },
          body: JSON.stringify({ p_device_id: storageRes.deviceId })
        });
        if (keyRes.ok) {
          const keyData = await keyRes.json();
          if (keyData && keyData.api_key) sessionApiKey = keyData.api_key;
        }
      } catch(e) {
        console.error("API Key couldn't be fetched.", e);
      }
    }

    if (!sessionApiKey) {
      updateState({
        aiStatusText: `Hata: Bu cihaz için oturum bulunamadı. Lütfen Vercel web portalına giriş yapın!`,
        analysisProgress: 100,
        isAnalyzing: false,
        aiError: true
      });
      return;
    }

    updateState({ aiStatusText: "Araçlar gruplandırılıyor...", analysisProgress: 5 });
    const groups = groupTabsByModel(readyData);
    const groupNames = Object.keys(groups);
    
    const flatCarsList = [];
    for (let g = 0; g < groupNames.length; g++) {
      const gName = groupNames[g];
      const gCars = groups[gName];
      for (let i = 0; i < gCars.length; i++) {
        flatCarsList.push({ groupName: gName, carData: gCars[i] });
      }
    }

    // H.A.S.E. threshold: 200 listings
    if (flatCarsList.length >= 200) {
      await runBatchAnalysis(flatCarsList, groupNames, groups, activeConfig, sessionApiKey);
    } else {
      await runDirectAnalysis(flatCarsList, groupNames, groups, activeConfig, sessionApiKey);
    }

  } catch (error) {
    updateState({
      aiError: true,
      aiStatusText: `Hata: ${error.message}`,
      isAnalyzing: true,
      finalReport: null
    });
  }
}

async function runDirectAnalysis(flatCarsList, groupNames, groups, activeConfig, sessionApiKey) {
  let allGroupReports = [];
  let totalCars = flatCarsList.length;
  let processedCars = 0;

  updateState({ aiStatusText: `Analiz başladı. Yapay zeka yanıtları bekleniyor...`, analysisProgress: 5 });
  
  const chunkResults = new Array(flatCarsList.length).fill(null);
  
  await new Promise((resolveQueue) => {
    let currentIndex = 0;
    let activeRequests = 0;
    let timerId = null;
    let lastLaunchTime = 0;

    function processQueue() {
      if (isAnalysisCancelled) {
        cleanup();
        return;
      }

      if (currentIndex >= flatCarsList.length && activeRequests === 0) {
        cleanup();
        return;
      }

      const now = Date.now();
      const timeSinceLastLaunch = now - lastLaunchTime;

      if (currentIndex < flatCarsList.length && activeRequests < 12) {
        if (timeSinceLastLaunch >= 1200) {
          const workIndex = currentIndex++;
          const item = flatCarsList[workIndex];
          const { groupName: gName, carData: cData } = item;

          activeRequests++;
          lastLaunchTime = Date.now();

          analyzeCarData(cData, activeConfig.analyze_prompt, sessionApiKey)
            .then(finalReport => {
              if (isAnalysisCancelled) return;

              processedCars++;
              updateState({ 
                aiStatusText: `Araçlar analiz ediliyor (${processedCars}/${totalCars})...`,
                analysisProgress: 5 + Math.round((processedCars / totalCars) * 80)
              });

              let cleanTitle = finalReport.clean_title || cData.title;
              if (!finalReport.clean_title || finalReport.clean_title.length > 50) {
                const match = cData.title.match(/(?:[12][0-9]{3})/);
                if (match) {
                  cleanTitle = `${gName} ${match[0]} Model`;
                } else {
                  cleanTitle = gName;
                }
              }

              chunkResults[workIndex] = {
                groupName: gName,
                carData: {
                  title: cleanTitle,
                  price: cData.price,
                  url: cData.url,
                  images: cData.images, 
                  market_speed_score: finalReport.market_speed_score || null,
                  price_perf_score: finalReport.price_perf_score || null,
                  fair_price_score: finalReport.fair_price_score || null,
                  condition_score: finalReport.condition_score || null,
                  overall_score: finalReport.overall_score || null,
                  ai_report: finalReport.ai_report || "Analiz oluşturulamadı.",
                  vision_report: null,
                  defects: [],
                  positives: [],
                  competitor_analysis: finalReport.competitor_analysis || null,
                  detailed_specs: finalReport.detailed_specs || [],
                  damage_map: finalReport.damage_map || null
                }
              };
            })
            .catch(err => {
               console.error("Araç kuyrukta işlenirken hata:", err);
            })
            .finally(() => {
              activeRequests--;
              processQueue();
            });

          if (timerId) clearTimeout(timerId);
          timerId = setTimeout(processQueue, 1200);
        } else {
          const waitTime = 1200 - timeSinceLastLaunch;
          if (timerId) clearTimeout(timerId);
          timerId = setTimeout(processQueue, waitTime);
        }
      } else if (currentIndex < flatCarsList.length && activeRequests >= 12) {
        if (timerId) clearTimeout(timerId);
        timerId = setTimeout(processQueue, 100);
      }
    }

    function cleanup() {
      if (timerId) {
        clearTimeout(timerId);
        timerId = null;
      }
      resolveQueue();
    }

    processQueue();
  });

  if (isAnalysisCancelled) return;
  
  const allProcessedCars = chunkResults.filter(r => r !== null);
  
  for (let g = 0; g < groupNames.length; g++) {
    const gName = groupNames[g];
    const carsInGroup = allProcessedCars.filter(c => c.groupName === gName).map(c => c.carData);
    
    const groupConsolidated = {
      groupName: gName,
      group_logic: `${gName} analizi tamamlandı.`,
      cars: carsInGroup
    };
    allGroupReports.push(groupConsolidated);
  }

  await compileMasterReportAndComplete(allGroupReports, activeConfig, sessionApiKey);
}

async function runBatchAnalysis(flatCarsList, groupNames, groups, activeConfig, sessionApiKey) {
  updateState({ aiStatusText: "Büyük Veri Modu: İstek dosyası hazırlanıyor...", analysisProgress: 6 });
  
  const jsonlContent = prepareBatchJsonl(flatCarsList, activeConfig.analyze_prompt);
  
  updateState({ aiStatusText: "Büyük Veri Modu: OpenAI sunucularına dosya yükleniyor...", analysisProgress: 8 });
  
  const formData = new FormData();
  const fileBlob = new Blob([jsonlContent], { type: 'application/jsonl' });
  formData.append('file', fileBlob, 'batch_requests.jsonl');
  formData.append('purpose', 'batch');

  let fileId = '';
  try {
    const fileRes = await fetch('https://api.openai.com/v1/files', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + sessionApiKey
      },
      body: formData
    });
    
    if (!fileRes.ok) {
      const errJson = await fileRes.json().catch(() => ({}));
      throw new Error(errJson.error?.message || `Dosya yükleme hatası (Kod: ${fileRes.status})`);
    }
    
    const fileData = await fileRes.json();
    fileId = fileData.id;
  } catch(e) {
    throw new Error(`OpenAI Dosya Yükleme Başarısız: ${e.message}`);
  }

  if (isAnalysisCancelled) return;

  updateState({ aiStatusText: "Büyük Veri Modu: Toplu işlem sırası oluşturuluyor...", analysisProgress: 12 });

  let batchId = '';
  try {
    const batchRes = await fetch('https://api.openai.com/v1/batches', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + sessionApiKey
      },
      body: JSON.stringify({
        input_file_id: fileId,
        endpoint: '/v1/chat/completions',
        completion_window: '24h'
      })
    });

    if (!batchRes.ok) {
      const errJson = await batchRes.json().catch(() => ({}));
      throw new Error(errJson.error?.message || `Batch oluşturma hatası (Kod: ${batchRes.status})`);
    }

    const batchData = await batchRes.json();
    batchId = batchData.id;
  } catch(e) {
    throw new Error(`OpenAI Toplu İşlem (Batch) Başlatılamadı: ${e.message}`);
  }

  updateState({
    isAnalyzing: true,
    activeBatchId: batchId,
    batchFlatCars: flatCarsList,
    batchConfig: activeConfig,
    aiStatusText: "Büyük Veri Modu: OpenAI işlemi sıraya aldı (Bekleniyor)...",
    analysisProgress: 15
  });

  await resumeBatchPolling(batchId, flatCarsList, activeConfig, sessionApiKey);
}

function prepareBatchJsonl(flatCarsList, dynamicPrompt) {
  const systemPrompt = dynamicPrompt || DEFAULT_ANALYZE_PROMPT;

  let lines = [];
  flatCarsList.forEach((item, index) => {
    const cData = item.carData;
    const dataForAi = { ...cData };
    delete dataForAi.images;
    
    const reqObj = {
      custom_id: `car-${index}`,
      method: "POST",
      url: "/v1/chat/completions",
      body: {
        model: "gpt-4o-mini",
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: JSON.stringify(dataForAi) }
        ],
        max_tokens: 4096,
        response_format: { type: 'json_object' }
      }
    };
    lines.push(JSON.stringify(reqObj));
  });
  return lines.join('\n');
}

async function resumeBatchPolling(batchId, flatCarsList, activeConfig, sessionApiKey) {
  let isDone = false;
  let statusCheckCount = 0;

  while (!isDone) {
    if (isAnalysisCancelled) {
      await cancelOpenAIBatch(batchId, sessionApiKey);
      updateState({ activeBatchId: null, batchFlatCars: null, batchConfig: null, isAnalyzing: false });
      return;
    }

    try {
      const batchCheck = await fetch(`https://api.openai.com/v1/batches/${batchId}`, {
        method: 'GET',
        headers: {
          'Authorization': 'Bearer ' + sessionApiKey
        }
      });

      if (!batchCheck.ok) {
        const errJson = await batchCheck.json().catch(() => ({}));
        throw new Error(errJson.error?.message || `Sorgu hatası (Kod: ${batchCheck.status})`);
      }

      const batchStatus = await batchCheck.json();
      const status = batchStatus.status;

      statusCheckCount++;

      if (status === 'completed') {
        isDone = true;
        updateState({ aiStatusText: "Büyük Veri Modu: Analiz sonuçları indiriliyor...", analysisProgress: 75 });
        await downloadAndCompileBatchResults(batchStatus.output_file_id, flatCarsList, activeConfig, sessionApiKey);
      } else if (status === 'failed' || status === 'expired' || status === 'cancelled') {
        throw new Error(`OpenAI toplu işlemi başarısız oldu (Durum: ${status})`);
      } else {
        let progressPercent = 15 + Math.min(statusCheckCount, 55);
        let countsText = '';
        if (batchStatus.request_counts) {
          const { completed, total, failed } = batchStatus.request_counts;
          countsText = ` (${completed}/${total} araç)`;
          if (total > 0) {
            progressPercent = 15 + Math.round((completed / total) * 55);
          }
        }
        
        updateState({
          aiStatusText: `Büyük Veri Modu: Yapay zeka analiz ediyor${countsText}...`,
          analysisProgress: progressPercent
        });

        await new Promise(r => setTimeout(r, 10000));
      }
    } catch(e) {
      console.error("Batch polling error:", e);
      updateState({
        aiError: true,
        aiStatusText: `Hata: ${e.message}`,
        isAnalyzing: true,
        activeBatchId: null,
        batchFlatCars: null,
        batchConfig: null
      });
      return;
    }
  }
}

async function cancelOpenAIBatch(batchId, apiKey) {
  try {
    await fetch(`https://api.openai.com/v1/batches/${batchId}/cancel`, {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + apiKey
      }
    });
  } catch(e) {
    console.error("OpenAI batch cancellation failed:", e);
  }
}

async function downloadAndCompileBatchResults(outputFileId, flatCarsList, activeConfig, sessionApiKey) {
  try {
    const contentRes = await fetch(`https://api.openai.com/v1/files/${outputFileId}/content`, {
      method: 'GET',
      headers: {
        'Authorization': 'Bearer ' + sessionApiKey
      }
    });

    if (!contentRes.ok) {
      throw new Error(`Sonuç indirme başarısız (Kod: ${contentRes.status})`);
    }

    const resultsText = await contentRes.text();
    const resultLines = resultsText.trim().split('\n');
    const resultsMap = {};

    resultLines.forEach(line => {
      if (!line) return;
      try {
        const parsed = JSON.parse(line);
        const customId = parsed.custom_id;
        if (parsed.response && parsed.response.status_code === 200) {
          const content = parsed.response.body.choices[0].message.content;
          resultsMap[customId] = JSON.parse(content);
        } else {
          console.error(`Batch item failure for ${customId}:`, parsed.error);
        }
      } catch(e) {
        console.error("Failed to parse JSONL line:", e);
      }
    });

    const chunkResults = new Array(flatCarsList.length).fill(null);

    flatCarsList.forEach((item, index) => {
      const customId = `car-${index}`;
      const finalReport = resultsMap[customId] || {
        clean_title: item.carData.title || "Bilinmeyen Araç",
        market_speed_score: 0,
        price_perf_score: 0,
        fair_price_score: 0,
        condition_score: 0,
        overall_score: 0,
        ai_report: "Bu araç OpenAI Batch işleminde hata aldığı veya zaman aşımına uğradığı için analiz edilemedi.",
        detailed_specs: [],
        competitor_analysis: null,
        damage_map: null
      };

      const gName = item.groupName;
      const cData = item.carData;

      let cleanTitle = finalReport.clean_title || cData.title;
      if (!finalReport.clean_title || finalReport.clean_title.length > 50) {
        const match = cData.title.match(/(?:[12][0-9]{3})/);
        if (match) {
          cleanTitle = `${gName} ${match[0]} Model`;
        } else {
          cleanTitle = gName;
        }
      }

      chunkResults[index] = {
        groupName: gName,
        carData: {
          title: cleanTitle,
          price: cData.price,
          url: cData.url,
          images: cData.images, 
          market_speed_score: finalReport.market_speed_score || null,
          price_perf_score: finalReport.price_perf_score || null,
          fair_price_score: finalReport.fair_price_score || null,
          condition_score: finalReport.condition_score || null,
          overall_score: finalReport.overall_score || null,
          ai_report: finalReport.ai_report || "Analiz oluşturulamadı.",
          vision_report: null,
          defects: [],
          positives: [],
          competitor_analysis: finalReport.competitor_analysis || null,
          detailed_specs: finalReport.detailed_specs || [],
          damage_map: finalReport.damage_map || null
        }
      };
    });

    const allGroupReports = [];
    const groupNames = Array.from(new Set(flatCarsList.map(item => item.groupName)));

    for (let g = 0; g < groupNames.length; g++) {
      const gName = groupNames[g];
      const carsInGroup = chunkResults.filter(c => c && c.groupName === gName).map(c => c.carData);
      
      const groupConsolidated = {
        groupName: gName,
        group_logic: `${gName} analizi tamamlandı.`,
        cars: carsInGroup
      };
      allGroupReports.push(groupConsolidated);
    }

    await compileMasterReportAndComplete(allGroupReports, activeConfig, sessionApiKey);

  } catch(e) {
    throw new Error(`Batch Sonuçları İşlenemedi: ${e.message}`);
  }
}

async function compileMasterReportAndComplete(allGroupReports, activeConfig, sessionApiKey) {
  updateState({ aiStatusText: `Master AI Tüm Grupları Kıyaslıyor...`, analysisProgress: 85 });

  let topCars = [];
  for (let g of allGroupReports) {
    for (let c of g.cars) {
      topCars.push({ groupName: g.groupName, car: c });
    }
  }
  
  topCars.sort((a, b) => {
    let scoreA = parseInt(a.car.overall_score, 10) || 0;
    let scoreB = parseInt(b.car.overall_score, 10) || 0;
    if (scoreB !== scoreA) return scoreB - scoreA;
    return (a.car.url || "").localeCompare(b.car.url || "");
  });

  let topN = 10;
  if (topCars.length > 10) {
    let tenthScore = parseInt(topCars[9].car.overall_score, 10) || 0;
    while (topN < topCars.length && (parseInt(topCars[topN].car.overall_score, 10) || 0) >= tenthScore) {
       topN++;
    }
  }
  
  const masterHavuz = topCars.slice(0, topN);
  
  const masterGroupReports = masterHavuz.map(item => ({
    groupName: item.groupName,
    cars: [item.car]
  }));

  updateState({ aiStatusText: "Büyük Master AI Raporu oluşturuluyor...", analysisProgress: 95 });
  const globalSummary = await generateGlobalMasterReport(masterGroupReports, activeConfig.master_prompt, sessionApiKey);

  updateState({
    analysisProgress: 100,
    aiStatusText: `Analiz Tamamlandı!`,
    isAnalyzing: false,
    finalReport: { groups: allGroupReports, summaryData: globalSummary },
    activeBatchId: null,
    batchFlatCars: null,
    batchConfig: null
  });
}

// ------------------------------------------------------------------
// MESSAGE LISTENER
// ------------------------------------------------------------------
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  chrome.storage.local.get([
    'trackedTabs', 'isAnalyzing', 'analysisProgress', 'aiStatusText', 
    'finalReport', 'aiError', 'collectedVehicles', 'isCollecting'
  ], (res) => {
    if (res.trackedTabs) trackedTabs = res.trackedTabs;
    if (res.isAnalyzing !== undefined) isAnalyzing = res.isAnalyzing;
    if (res.analysisProgress !== undefined) analysisProgress = res.analysisProgress;
    if (res.aiStatusText) aiStatusText = res.aiStatusText;
    if (res.finalReport) finalReport = res.finalReport;
    if (res.aiError !== undefined) aiError = res.aiError;
    if (res.collectedVehicles) collectedVehicles = res.collectedVehicles;
    if (res.isCollecting !== undefined) isCollecting = res.isCollecting;

    handleMessage(request, sender, sendResponse);
  });
  return true; // Asenkron yanıt kanalı açık kalsın
});

function handleMessage(request, sender, sendResponse) {
  if (request.action === 'passive_extract') {
    if (!isCollecting || isAnalyzing) {
      sendResponse({ success: false });
      return;
    }
    const data = request.data;
    let existing = trackedTabs.find(t => t.url === data.url);
    if (!existing) {
      const newTab = {
        tabId: sender.tab ? sender.tab.id : `passive_${Date.now()}_${Math.random()}`,
        url: data.url,
        title: data.title,
        status: 'Yüklendi',
        data: data
      };
      trackedTabs.push(newTab);
      updateState({ trackedTabs });
    } else {
      if (!existing.data) {
        existing.status = 'Yüklendi';
        existing.data = data;
        existing.title = data.title;
        updateState({ trackedTabs });
      }
    }
    sendResponse({ success: true });
    return;
  }

  if (request.action === 'get_state') {
    sendResponse({
      tabs: trackedTabs,
      isAnalyzing: isAnalyzing,
      progress: analysisProgress,
      aiText: aiStatusText,
      finalReport: finalReport,
      isError: aiError,
      collectedCount: trackedTabs.length,
      collectedVehicles: trackedTabs,
      isCollecting: isCollecting
    });
    return;
  }

  if (request.action === 'set_collecting') {
    updateState({ isCollecting: request.value });
    
    if (request.value === true) {
      chrome.tabs.query({}, (tabs) => {
        let matchedTabs = tabs.filter(tab => {
          const url = tab.url;
          return url && (url.includes('sahibinden.com/ilan/') || url.includes('arabam.com/ilan/'));
        });
        
        let delay = 0;
        matchedTabs.forEach(tab => {
          setTimeout(() => {
            chrome.storage.local.get(['trackedTabs'], (res) => {
              const currentTabs = res.trackedTabs || [];
              addTabToTrackingAndExtract(tab.id, tab.url, tab.title, currentTabs);
            });
          }, delay);
          delay += 150;
        });
      });
    }

    sendResponse({ success: true });
    return;
  }

  if (request.action === 'remove_vehicle') {
    collectedVehicles = collectedVehicles.filter(v => v.url !== request.url);
    updateState({ collectedVehicles: collectedVehicles });
    sendResponse({ success: true });
    return;
  }

  if (request.action === 'reset_memory') {
    isAnalysisCancelled = true;
    updateState({
      trackedTabs: [],
      finalReport: null,
      aiError: false,
      isAnalyzing: false,
      aiStatusText: '',
      isCollecting: false
    });
    sendResponse({ success: true });
    return;
  }

  if (request.action === 'cancel_analysis') {
    isAnalysisCancelled = true;
    
    chrome.storage.local.get(['activeBatchId', 'deviceId'], async (res) => {
      if (res.activeBatchId && res.deviceId) {
        let sessionApiKey = '';
        try {
          const keyRes = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/rpc/get_session_api_key`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'apikey': CONFIG.SUPABASE_ANON_KEY,
              'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY}`
            },
            body: JSON.stringify({ p_device_id: res.deviceId })
          });
          if (keyRes.ok) {
            const keyData = await keyRes.json();
            if (keyData && keyData.api_key) sessionApiKey = keyData.api_key;
          }
        } catch(e) {}
        if (sessionApiKey) {
          cancelOpenAIBatch(res.activeBatchId, sessionApiKey);
        }
      }
    });

    updateState({
      trackedTabs: [],
      finalReport: null,
      aiError: false,
      isAnalyzing: false,
      aiStatusText: '',
      isCollecting: false,
      analysisProgress: 0,
      activeBatchId: null,
      batchFlatCars: null,
      batchConfig: null
    });
    sendResponse({ success: true });
    return;
  }

  if (request.action === 'show_report') {
    if (!finalReport) {
      sendResponse({ success: false });
      return;
    }
    const portalUrl = CONFIG.PORTAL_URL;
    chrome.tabs.create({ url: portalUrl }, (tab) => {
      chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
        if (tabId === tab.id && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            world: 'MAIN',
            func: (data) => {
              window.localStorage.setItem('autocar_ai_result', JSON.stringify(data));
              window.dispatchEvent(new Event('autocar_report_ready'));
            },
            args: [finalReport]
          });
        }
      });
    });
    sendResponse({ success: true });
    return;
  }

  if (request.action === 'remove_tab') {
    trackedTabs = trackedTabs.filter(t => t.url !== request.url);
    updateState({ trackedTabs: trackedTabs });
    sendResponse({ success: true });
    return;
  }

  if (request.action === 'start_analysis') {
    const readyData = trackedTabs.map(t => t.data).filter(d => d !== null);
    if (readyData.length === 0) {
      updateState({ aiError: true, aiStatusText: "Analiz edilecek araç verisi yok." });
      sendResponse({ success: false });
      return;
    }
    isAnalysisCancelled = false;
    updateState({ isAnalyzing: true, analysisProgress: 5, aiStatusText: "Yapay Zeka Hazırlanıyor..." });
    runFullAnalysis();
    sendResponse({ success: true });
    return;
  }
}
